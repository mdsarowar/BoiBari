<?php

return array (
  'IndiaApplicable' => '',
  'pincode' => '',
  'preferPayout' => '',
);
