<?php

return array (
  'failed' => 'Kredensial ini tidak cocok dengan catatan kami.',
  'throttle' => 'Terlalu banyak upaya masuk. Silakan coba lagi dalam :seconds detik.',
);
