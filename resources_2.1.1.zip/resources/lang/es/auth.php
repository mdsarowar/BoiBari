<?php

return array (
  'failed' => 'Estas credenciales no coinciden con nuestros registros.',
  'throttle' => 'Demasiados intentos de inicio de sesión. Por favor intente nuevamente en :seconds segundos.',
);
