<?php

return array (
  'next' => 'Il prossimo "',
  'previous' => '«Precedente',
);
