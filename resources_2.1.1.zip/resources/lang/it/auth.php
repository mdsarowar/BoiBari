<?php

return array (
  'failed' => 'Queste credenziali non corrispondono ai nostri record.',
  'throttle' => 'Troppi tentativi di accesso. Riprova tra :seconds secondi.',
);
