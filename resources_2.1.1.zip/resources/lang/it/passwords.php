<?php

return array (
  'password' => 'Le password devono contenere almeno sei caratteri e corrispondere alla conferma.',
  'reset' => 'La tua password è stata resettata!',
  'sent' => 'Abbiamo inviato per e-mail il tuo link per reimpostare la password!',
  'token' => 'Questo token di reimpostazione della password non è valido.',
  'user' => 'Non riusciamo a trovare un utente con quell\'indirizzo e-mail.',
);
