<?php

return array (
  'failed' => 'Aceste acreditări nu se potrivesc cu înregistrările noastre.',
  'throttle' => 'Prea multe încercări de conectare. Încercați din nou în :seconds secunde.',
);
