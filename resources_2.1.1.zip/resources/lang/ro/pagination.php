<?php

return array (
  'next' => 'Următor → "',
  'previous' => '«Anterior',
);
