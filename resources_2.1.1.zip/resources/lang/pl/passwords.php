<?php

return array (
  'password' => 'Hasła muszą mieć co najmniej sześć znaków i muszą odpowiadać potwierdzeniu.',
  'reset' => 'Twoje hasło zostało zresetowane!',
  'sent' => 'Prześlemy Ci e-mailem link do resetowania hasła!',
  'token' => 'Ten token resetowania hasła jest nieprawidłowy.',
  'user' => 'Nie możemy znaleźć użytkownika o tym adresie e-mail.',
);
