<?php

return array (
  'failed' => 'Te dane uwierzytelniające nie są zgodne z naszymi danymi.',
  'throttle' => 'Zbyt wiele prób logowania. Spróbuj ponownie za :seconds sekund.',
);
