<?php

return array (
  'next' => 'Kolejny "',
  'previous' => '«Poprzedni',
);
