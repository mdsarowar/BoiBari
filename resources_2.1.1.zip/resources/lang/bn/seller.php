<?php

return array (
  'Dashboard' => '',
  'NO' => '',
  'Orders' => '',
  'Profile' => '',
  'YES' => '',
);
