<?php

return array (
  'NO' => '',
  'No' => '',
);
