<?php

return array (
  'next' => 'Järgmine »',
  'previous' => '«Eelmine',
);
