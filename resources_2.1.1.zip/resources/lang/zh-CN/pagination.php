<?php

return array (
  'next' => '下一个 ”',
  'previous' => '«上一页',
);
