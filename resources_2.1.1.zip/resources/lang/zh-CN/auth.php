<?php

return array (
  'failed' => '这些凭据与我们的记录不匹配。',
  'throttle' => '登录尝试过多。请在1秒钟后重试。',
);
